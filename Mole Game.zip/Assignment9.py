import pygame
import random


pygame.init()
WINDOW_WIDTH = 640
WINDOW_HEIGHT = 480
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Whack-a-Mole")


GAME_DURATION = 50 
MOLE_APPEARANCE_INTERVAL = 4
SCORE_INCREMENT = 10
MOLE_IMAGE_PATH = "mole.png"
BACKGROUND_IMAGE_PATH = "background.png"
FONT_PATH = "arial.ttf"
FONT_SIZE = 32



mole_image = pygame.image.load(MOLE_IMAGE_PATH)
background_image = pygame.image.load(BACKGROUND_IMAGE_PATH)
font = pygame.font.Font(FONT_PATH, FONT_SIZE)


score = 0
game_start_time = pygame.time.get_ticks()
game_end_time = game_start_time + GAME_DURATION * 1000
mole_rect = None
next_mole_time = game_start_time

def display_score():
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    screen.blit(score_text, (10, 10))

def display_time_left():
    time_left = max(0, game_end_time - pygame.time.get_ticks()) // 1000
    time_text = font.render(f"Time left: {time_left}", True, (255, 255, 255))
    screen.blit(time_text, (WINDOW_WIDTH - time_text.get_width() - 10, 10))

def show_mole():

    global mole_rect, next_mole_time, mole_appear_time
    current_time = pygame.time.get_ticks()
    if current_time >= next_mole_time:
        mole_x = random.randint(0, WINDOW_WIDTH - mole_image.get_width())
        mole_y = random.randint(0, WINDOW_HEIGHT - mole_image.get_height())
        mole_rect = screen.blit(mole_image, (mole_x, mole_y))
        mole_appear_time = current_time
        next_mole_time = current_time + MOLE_APPEARANCE_INTERVAL * 1000

    elif mole_rect and current_time >= (mole_appear_time + 30000):
        mole_rect = None



clock = pygame.time.Clock()
running = True
while running:
    pygame.time.wait(1000)
    clock.tick(60) 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:

            event_x = event.pos[0]
            event_y = event.pos[1]

            if (mole_rect and event_x >= mole_rect.x + 70 and event_x <= mole_rect.x + mole_rect.width - 80 and event_y >= mole_rect.y + 60 and event_y <= mole_rect.y + mole_rect.height - 60):
                score += SCORE_INCREMENT
                mole_rect = None


    screen.blit(background_image, (0, 0))
    show_mole()
    if pygame.time.get_ticks() < game_end_time:
        display_time_left()
    display_score()

    
    if pygame.time.get_ticks() > game_end_time:
        running = False

    
    pygame.display.flip()


final_score_text = font.render(f"Your total score this run was: {score}", True, (255, 255, 255))
screen.blit(final_score_text, ((WINDOW_WIDTH - final_score_text.get_width()) // 2, WINDOW_HEIGHT // 2 - FONT_SIZE))
pygame.display.flip()


pygame.time.wait(3000)
pygame.quit()
